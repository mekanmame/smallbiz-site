
# Secur HTML Template – Azure Static Web Apps Ready

This folder is ready to push to GitHub and deploy via **Azure Static Web Apps**.

## Structure
- `index.html` + other `.html` pages
- `css/`, `js/`, `images/` (or `assets/`) – vendor assets
- `staticwebapp.config.json` – 404 handling, MIME types
- `404.html` – friendly not found page

## Azure SWA settings
- **Build preset:** Custom/None
- **App location:** `/`
- **Output location:** `/`
- **API location:** *(leave empty)*
- No build commands required.

If links to assets look broken after deploy, make sure your HTML uses **relative paths** like:
```html
<link rel="stylesheet" href="css/style.css">
<script src="js/main.js"></script>
<img src="images/hero.jpg" alt="">
```
(Absolute paths like `/css/style.css` were removed in this package.)

## Contact form (no backend)
Use a service like Formspree or Microsoft Forms/Bookings. Example:
```html
<form action="https://formspree.io/f/YOUR_ID" method="POST">
  <input name="name" required>
  <input type="email" name="email" required>
  <textarea name="message" required></textarea>
  <button type="submit" class="btn btn-primary">Send</button>
</form>
```

Happy shipping!
